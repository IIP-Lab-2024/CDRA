#!/bin/bash

source "batch_jobs/_experiment_configuration.sh"

# Actual time:   ["bert-base-uncased"]="00:15:00" ["albert-base-v2"]="00:10:00" ["roberta-base"]="00:10:00" ["gpt2"]="00:15:00"
declare -A time=(["bert-base-uncased"]="00:30:00" ["albert-base-v2"]="00:30:00" ["roberta-base"]="00:30:00" ["gpt2"]="00:30:00")


#for model in ${models[@]}; do
#    experiment_id="seat_m-${model}_c-${model_to_model_name_or_path[${model}]}"
#    if [ ! -f "${persistent_dir}/results/epoch1/wiki-2.5/seat/${experiment_id}.json" ]; then
#        echo ${experiment_id}
#        python experiments/seat.py \
#            --tests ${seat_tests} \
#            --model ${model} \
#            --model_name_or_path ${model_to_model_name_or_path[${model}]} \
#            --persistent_dir ${persistent_dir}
#    fi
#done

#for model in ${models[@]}; do
#    experiment_id="seat_m-${model}_c-${model_to_model_name_or_path[${model}]}"
#    if [ ! -f "${persistent_dir}/results/seat/${experiment_id}.json" ]; then
#        echo ${experiment_id}
#        sbatch \
#            --time ${time[${model_to_model_name_or_path[${model}]}]} \
#            --partition=long \
#            -J ${experiment_id} \
#            -o /mnt/nlp/zwx/bias-bench-main/logs/%x.%j.out \
#            -e /mnt/nlp/zwx/bias-bench-main/logs/%x.%j.err \
#            python_job.sh experiments/seat.py \
#                --tests ${seat_tests} \
#                --model ${model} \
#                --model_name_or_path ${model_to_model_name_or_path[${model}]}
#    fi
#done

#for model in ${models[@]}; do
#    experiment_id="${model}_c}"
#    if [ ! -f "${persistent_dir}/results/seat/${experiment_id}.json" ]; then
#        echo ${experiment_id}
#        python experiments/seat.py \
#            --tests ${seat_tests} \
#            --model ${model} \
#            --model_name_or_path "/date1/zwx/bias-bench-main/gpt2" \
#            --persistent_dir ${persistent_dir} \
#            --output_path "${persistent_dir}/results/crows/${experiment_id}.json"
#
#    fi
#done
for model in ${models[@]}; do
    experiment_id="${model}_c"
    if [ ! -f "${persistent_dir}/results/seat/${experiment_id}.json" ]; then
        echo ${experiment_id}
         python experiments/seat.py \
            --tests ${seat_tests} \
            --model ${model} \
            --model_name_or_path "/date1/zwx/bias-bench-main/gpt2" \
            --persistent_dir ${persistent_dir} \
            --output_path "${persistent_dir}/results/seat/${experiment_id}.json"

    fi
done
