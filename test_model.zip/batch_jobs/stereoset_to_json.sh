#!/bin/bash
source "batch_jobs/_experiment_configuration.sh"

python experiments/stereoset_evaluation.py \
  --predictions_dir "${persistent_dir}/results/stereoset" \
  --output_file "${persistent_dir}/results/stereoset/test/results.json" \
  --persistent_dir ${persistent_dir}