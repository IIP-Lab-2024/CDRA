def _is_generative(model):
    # Checks if we are running an autoregressive model.
    return model in [
        "GPT2LMHeadModel",
        "Llama2LMHeadModel",
        "BloomLMHeadModel",
        "SentenceDebiasGPT2LMHeadModel",
        "SentenceDebiasLlama2LMHeadModel",
        "INLPGPT2LMHeadModel",
        "INLPLlama2LMHeadModel",
        "CDAGPT2LMHeadModel",
        "CDALlama2LMHeadModel",
        "CDABloomLMHeadModel",
        "DropoutGPT2LMHeadModel",
        "DropoutLlama2LMHeadModel",
        "SelfDebiasLlama2LMHeadModel",
        "SelfDebiasGPT2LMHeadModel",
    ]


def _is_self_debias(model):
    # Checks if we are running a Self-Debias model.
    return model in [
        "SelfDebiasGPT2LMHeadModel",
        "SelfDebiasBertForMaskedLM",
        "SelfDebiasAlbertForMaskedLM",
        "SelfDebiasRobertaForMaskedLM",
    ]
