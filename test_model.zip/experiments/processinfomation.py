import pandas as pd
import json
import os
from openpyxl import load_workbook
from openpyxl import Workbook


# 服务器上的数据文件夹路径
folder_path = '/mnt/nlp/bias-bench-main/results/seat/'

# 加载现有的Excel工作簿
excel_path = "/mnt/nlp/zwx/bias-bench-main/results/seat/wiki-10/SEAT1.xlsx"  # 修改为您的Excel文件路径

if not os.path.exists(excel_path):
    print("Excel文件不存在，正在创建...")

    # 创建一个新的Excel工作簿
    wb = Workbook()
    ws = wb.active
    ws.title = 'Sheet1'

    # 保存工作簿
    wb.save(excel_path)

# 初始化一个空的DataFrame，用于存储所有数据
all_data = pd.DataFrame()

# 读取服务器文件夹中的所有JSON文件
for filename in os.listdir(folder_path):
    # 构造完整的文件路径
    file_path = os.path.join(folder_path, filename)
    # 确保是JSON文件1
    if filename.endswith('.json'):
        # 读取JSON文件
        with open(file_path, 'r') as file:
            data = json.load(file)
            # 将JSON数据转换为DataFrame
            df = pd.DataFrame(data)
            # 添加到all_data DataFrame中
            all_data = pd.concat([all_data, df], ignore_index=True)

# 如果对应的test值没有，则设置为null
all_data['effect_size'].fillna('null', inplace=True)

# 使用pivot来转换数据，使得experiment_id为索引，test为列
pivot_df = all_data.pivot(index='experiment_id', columns='test', values='effect_size').reset_index()

# 加载Excel工作簿
wb = load_workbook(excel_path)
ws = wb.active

# 定位到最后一行
last_row = ws.max_row if ws.max_row else 1

# 为了避免直接写入到最后一行导致的覆盖，我们先移动到下一行
if last_row > 1:
    last_row += 1  # 使其下移，避免覆盖已有的数据

# 写入数据到Excel工作表
for index, row in pivot_df.iterrows():
    # 由于使用了reset_index，第一列现在是experiment_id
    ws.append(row.fillna('null').tolist())
    # 添加空行作为分隔符
    ws.append(['null'] * len(row))
    ws.append(['null'] * len(row))
    last_row += len(row) + 2  # 更新最后一行的位置

# 保存工作簿
wb.save(excel_path)