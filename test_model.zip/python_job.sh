#!/bin/bash
#SBATCH --partition=main
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:16gb:1
#SBATCH --mem=8GB
#SBATCH --time=00:30:00

source batch_jobs/_experiment_configuration.sh

echo "Host - $HOSTNAME"
echo "Commit - $(git rev-parse HEAD)"
nvidia-smi

#module load python/3.9

#virtualenv $SLURM_TMPDIR/env
#source $SLURM_TMPDIR/env/bin/activate

#source /home/work/anaconda3/envs/zwx_bias-bench/bin/activate
# Install dependencies.
#cd $HOME/workspace/debias-eval
#cd /mnt/nlp/zwx/bias-bench-main

#python -m pip install -e .


# Run code.
python -u "$@" --persistent_dir ${persistent_dir}
