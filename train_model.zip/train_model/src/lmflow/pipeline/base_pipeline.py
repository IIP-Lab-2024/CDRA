#!/usr/bin/env python
# coding=utf-8
""" BasePipeline.
"""

from abc import ABC         # abstract class

class BasePipeline(ABC):
    pass
