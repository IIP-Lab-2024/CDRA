import torch
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer

def split_sentences(text):
    sentences = text.split(". ")
    # 确保只分割成两部分
    if len(sentences) == 2:
        return sentences[0] + ".", sentences[1]
    else:
        return None, None


class MyDataset(Dataset):
    def __init__(self, texts, tokenizer, max_length=128):
        self.tokenizer = tokenizer
        self.texts = texts
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = self.texts[idx]
        sent1, sent2 = split_sentences(text)
        if sent1 and sent2:  # 确保分割成功
            encoding = self.tokenizer(sent1, sent2,
                                      truncation=True,
                                      padding='max_length',
                                      max_length=self.max_length,
                                      return_tensors="pt")
            return encoding
        else:
            return None
